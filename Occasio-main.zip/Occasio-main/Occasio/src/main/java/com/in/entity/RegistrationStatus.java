package com.in.entity;

public enum RegistrationStatus {
	SUCCESS,PENDING,FAILURE,SUSPENDED,CANCELLED
}
