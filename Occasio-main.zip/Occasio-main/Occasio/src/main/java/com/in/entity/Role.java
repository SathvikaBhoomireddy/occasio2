package com.in.entity;

public enum Role {
	ATTENDEE,ORGANIZER,ADMIN;
}
