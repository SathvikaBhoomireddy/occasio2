package com.in;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OccasioApplicationTests {

	@Test
	void contextLoads() {
	}

}
