Run this Maven Project and access the below URL

AccessURL:"localhost:8080/swagger-ui.html"
